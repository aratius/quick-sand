import "../styles/app.scss"

export default function App({ Component, pageProps }: any) {
	return <Component {...pageProps} />
}